
#include <stdio.h>

/*
	DO NOT change this file.
*/

int   cmpr_int(void*, void*);
int   cmpr_float(void*,void*);
void  print_int(void*);
void  print_float(void*);
void* read_array(char* filename, char* format, size_t* len);